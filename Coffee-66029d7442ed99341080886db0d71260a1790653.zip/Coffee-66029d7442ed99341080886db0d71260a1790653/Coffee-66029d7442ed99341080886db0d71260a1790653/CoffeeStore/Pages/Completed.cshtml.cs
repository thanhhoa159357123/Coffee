using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CoffeeStore.Pages
{
    public class CompletedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
